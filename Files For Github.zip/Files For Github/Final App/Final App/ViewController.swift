//
//  SceneDelegate.swift
//  Final App
//
//  Created by Rushi Kadali on 2020-02-07.
//  Copyright © 2020 Aluminum Co. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var curvedlineChart: LineChart!
    @IBOutlet weak var sege: UISegmentedControl!
    
    var timer: Timer?
    var timers: Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.white
        
        // Sample dataset
        let dataEntries = [PointEntry(value: 0, label: ""),
                           PointEntry(value: 16, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 12, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 12, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 16, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 19, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 25, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 16, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 16, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 12, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 12, label: ""),
                           PointEntry(value: 19, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 25, label: ""),
                           PointEntry(value: 0, label: "")]
        
        // let dataEntries = generateRandomEntries()
        
        curvedlineChart.dataEntries = dataEntries
        curvedlineChart.isCurved = true
        
        //timer = Timer.scheduledTimer(withTimeInterval: 15, repeats: false, block: {_ in self.c()})
        
        //timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: {_ in self.updateChart()})
        
    }
    
    @objc func updateChart() {
        curvedlineChart.dataEntries = chartData
        curvedlineChart.isCurved = true
    }
    
    @objc func c() {
        
    }
    
    @IBAction func charts(_ sender: Any) {
        
        var dataEntries = [PointEntry(value: 0, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 16, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 19, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 25, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 16, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 19, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 25, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 0, label: "")]
        
        if sege.selectedSegmentIndex == 0 {
            dataEntries = [PointEntry(value: 0, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 16, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 19, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 25, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 16, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 19, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 25, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 0, label: "")]
            
            curvedlineChart.dataEntries = dataEntries
            curvedlineChart.isCurved = true
        }
        
        if sege.selectedSegmentIndex == 1 {
            dataEntries = [PointEntry(value: 0, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 19, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 25, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 19, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 25, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 16, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 16, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 12, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 12, label: ""),
                           PointEntry(value: 19, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 25, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 0, label: "")]
            
            curvedlineChart.dataEntries = dataEntries
            curvedlineChart.isCurved = true
        }
        
        if sege.selectedSegmentIndex == 2 {
            dataEntries = [PointEntry(value: 0, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 25, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 12, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 19, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 25, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 23, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 25, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 12, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 18, label: ""),
                           PointEntry(value: 24, label: ""),
                           PointEntry(value: 19, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 0, label: "")]
            
            curvedlineChart.dataEntries = dataEntries
            curvedlineChart.isCurved = true
        }
        if sege.selectedSegmentIndex == 3 {
            dataEntries = [PointEntry(value: 0, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 21, label: ""),
                           PointEntry(value: 22, label: ""),
                           PointEntry(value: 20, label: ""),
                           PointEntry(value: 0, label: "")]
            
            curvedlineChart.dataEntries = dataEntries
            curvedlineChart.isCurved = true
        }
    }
    /*
     private func generateRandomEntries() -> [PointEntry] {
     var result: [PointEntry] = []
     for i in 0..<100 {
     let value = Int(arc4random() % 500)
     
     let formatter = DateFormatter()
     formatter.dateFormat = "d MMM"
     var date = Date()
     date.addTimeInterval(TimeInterval(24*60*60*i))
     
     result.append(PointEntry(value: value, label: ""))
     }
     return result
     }
     */
    
}
