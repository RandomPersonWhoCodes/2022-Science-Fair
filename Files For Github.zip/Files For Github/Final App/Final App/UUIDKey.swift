//
//  SceneDelegate.swift
//  Final App
//
//  Created by Rushi Kadali on 2020-02-07.
//  Copyright © 2020 Aluminum Co. All rights reserved.
//

import CoreBluetooth
//Uart Service uuid


let kBLEService_UUID = "0000FFE0-0000-1000-8000-00805F9B34FB"
let kBLE_Characteristic_uuid_Tx = "0000FFE1-0000-1000-8000-00805F9B34FB"
let kBLE_Characteristic_uuid_Rx = "0000FFE1-0000-1000-8000-00805F9B34FB"
let MaxCharacters = 20
// "E81D4B51-5D53-B465-7041-D1A40C7C8393"
let BLEService_UUID = CBUUID(string: kBLEService_UUID)
let BLE_Characteristic_uuid_Tx = CBUUID(string: kBLE_Characteristic_uuid_Tx) //(Property = Write without response)
let BLE_Characteristic_uuid_Rx = CBUUID(string: kBLE_Characteristic_uuid_Rx) // (Property = Read/Notify)
